<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class CartController extends Controller
{
    /**
     * Display the cart.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $cart = Session::get('cart', []);
        return view('cart', compact('cart'));
    }

    /**
     * Add an item to the cart.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function add(Request $request)
    {
        $item = $request->only(['stockID', 'stockName', 'stockPrice', 'quantity', 'stockQuantity']);
        $cart = Session::get('cart', []);

        // Check if item already exists in the cart
        foreach ($cart as &$existingItem) {
            if ($existingItem['stockID'] == $item['stockID']) {
                $existingItem['quantity'] += $item['quantity'];
                Session::put('cart', $cart);
                return redirect()->route('cart')->with('success', 'Item added to cart!');
            }
        }

        $cart[] = $item;
        Session::put('cart', $cart);

        return redirect()->route('cart')->with('success', 'Item added to cart!');
    }

    /**
     * Update an item in the cart.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request)
    {
        $cart = Session::get('cart', []);
        foreach ($cart as &$item) {
            if ($item['stockID'] == $request->stockID) {
                $item['quantity'] = $request->quantity;
                break;
            }
        }
        Session::put('cart', $cart);

        return redirect()->route('cart')->with('success', 'Cart updated!');
    }

    /**
     * Remove an item from the cart.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function remove(Request $request)
    {
        $cart = Session::get('cart', []);
        foreach ($cart as $key => $item) {
            if ($item['stockID'] == $request->stockID) {
                unset($cart[$key]);
                break;
            }
        }
        Session::put('cart', array_values($cart));

        return redirect()->route('cart')->with('success', 'Item removed from cart!');
    }

    /**
     * Clear the cart.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function clear()
    {
        Session::forget('cart');

        return redirect()->route('cart')->with('success', 'Cart cleared!');
    }
}