<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Stock;

class StockController extends Controller
{
    public function index()
    {
        $stocks = Stock::all();
        return view('requestPage', compact('stocks'));
    }

    public function filter(Request $request)
    {
        $category = $request->input('category');

        if ($category === 'all') {
            $stocks = Stock::all();
        } else {
            $stocks = Stock::where('category', $category)->get();
        }

        return view('requestPage', compact('stocks'));
    }
}
