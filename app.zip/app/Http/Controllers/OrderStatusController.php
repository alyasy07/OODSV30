<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;

class OrderStatusController extends Controller
{
    public function index()
    {
        $orders = Order::all(); // Fetch all orders
        return view('orderStatus', ['orders' => $orders]);
    }
}
