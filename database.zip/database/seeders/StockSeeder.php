<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class StockSeeder extends Seeder
{
    public function run()
    {
        DB::table('stocks')->insert([
            [
                'stocksName' => 'Cocoa Powder',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 89.00,
                'category' => 'powder',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stocksName' => 'Matcha Powder',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 89.00,
                'category' => 'powder',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stocksName' => 'Lotus Biscoff Spread',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 137.00,
                'category' => 'topping',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stocksName' => 'Honey',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 112.00,
                'category' => 'sweetener',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stocksName' => 'Fresh Milk',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 98.00,
                'category' => 'dairy',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stocksName' => 'Brown Sugar',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 155.00,
                'category' => 'sweetener',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stocksName' => 'Red Velvet Powder',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 89.00,
                'category' => 'powder',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stocksName' => 'Tapioca Pearl',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 87.00,
                'category' => 'topping',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stocksName' => 'Vanilla Syrup',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 119.00,
                'category' => 'syrup',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stocksName' => 'Oat Milk',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 109.00,
                'category' => 'dairy',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stocksName' => 'Strawberry Purees',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 88.00,
                'category' => 'topping',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stocksName' => 'Caramel Syrup',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 99.00,
                'category' => 'syrup',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stocksName' => 'Sweetened Creamer',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 108.00,
                'category' => 'sweetener',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stocksName' => 'Whipping Cream',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 115.00,
                'category' => 'dairy',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'stocksName' => 'Hazelnut Syrup',
                'stocksQuantity' => 10,
                'minQuantity' => '1',
                'price' => 109.00,
                'category' => 'syrup',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}

