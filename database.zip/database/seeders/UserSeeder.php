<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run()
    {
        $users = [
            [
                'userName' => 'kajangHQ',
                'phoneNumber' => '0163049343',
                'email' => 'smoothieflava@gmail.com',
                'password' => Hash::make('kajang'),
                'outletAddress' => '3, Jalan Seksyen 3/6, Taman Kajang Utama, Kajang, Malaysia, 43000',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'userName' => 'kuantanOutlet',
                'phoneNumber' => '01158702547',
                'email' => 'smooteatamantas@gmail.com',
                'password' => Hash::make('kuantan'),
                'outletAddress' => 'Lorong Pandan Damai 2/2, Taman Pandan Damai 2, 25150 Kuantan, Pahang, Kuantan, Malaysia, 25150',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'userName' => 'msuOutlet',
                'phoneNumber' => '0163049343',
                'email' => 'smoothieflava@gmail.com',
                'password' => Hash::make('msu'),
                'outletAddress' => 'Lot No 1, Naik Parking Hospital On the bridge) University Drive, Platters Foodmart, Off, Persiaran Olahraga, Seksyen 13, 40100 Shah Alam, Selangor',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        ];

        DB::table('users')->insert($users);
    }
}
